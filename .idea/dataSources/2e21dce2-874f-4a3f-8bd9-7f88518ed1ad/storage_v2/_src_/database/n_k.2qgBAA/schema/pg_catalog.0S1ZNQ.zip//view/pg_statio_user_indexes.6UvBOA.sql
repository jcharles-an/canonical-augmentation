create view pg_statio_user_indexes
            (relid, indexrelid, schemaname, relname, indexrelname, idx_blks_read, idx_blks_hit) as
SELECT pg_statio_all_indexes.relid,
       pg_statio_all_indexes.indexrelid,
       pg_statio_all_indexes.schemaname,
       pg_statio_all_indexes.relname,
       pg_statio_all_indexes.indexrelname,
       pg_statio_all_indexes.idx_blks_read,
       pg_statio_all_indexes.idx_blks_hit
FROM pg_statio_all_indexes
WHERE (pg_statio_all_indexes.schemaname <> ALL (ARRAY ['pg_catalog'::name, 'information_schema'::name]))
  AND pg_statio_all_indexes.schemaname !~ '^pg_toast'::text;

alter table pg_statio_user_indexes
    owner to jcharlesan;

grant select on pg_statio_user_indexes to public;

