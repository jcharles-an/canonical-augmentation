create function insert_into_line_13_pending_results() returns trigger
    language plpgsql
as
$$
                              BEGIN
                                IF NEW.stdout NOT LIKE 'Reserved-%' AND NEW.stdout NOT LIKE 'Done %' THEN
                                  INSERT INTO conf_17_4.line_13_pending_results (seq) VALUES (NEW.seq);
                                END IF;
                                RETURN NEW; 
                              END;
                              $$;

alter function insert_into_line_13_pending_results() owner to jcharlesan;

