create function process_line_10_stdout(seq_id integer) returns void
    language plpgsql
as
$$
                              DECLARE
                                line TEXT;
                                current_stdout TEXT;
                                solutions INTEGER := 0; -- Initialize solutions
                                certs NUMERIC[] := '{}';    -- Array to hold all certs
                                graphs TEXT[] := '{}';   -- Array to hold all graphs
                                batch_count INTEGER := 0;   -- Counter for items in current batch
                                BATCH_LIMIT INTEGER := 5000; -- <<<--- DEFINE YOUR BATCH LIMIT HERE (e.g., 1000, 5000, 10000)
                              BEGIN
                                SELECT stdout INTO current_stdout FROM conf_17_4.line_10 WHERE seq = seq_id;   
                                
                                 -- Handle case where stdout is empty or null, nothing to process
                                IF current_stdout IS NULL OR TRIM(current_stdout) = '' THEN
                                  UPDATE conf_17_4.line_10 SET stdout = 'Done 0' WHERE seq = seq_id;
                                  DELETE FROM conf_17_4.line_10_pending_results WHERE seq = seq_id;
                                  RETURN;
                                END IF;
                                
                                -- Parse all lines and collect certs and graphs into arrays, inserting in batches
                                FOR line IN SELECT * FROM unnest(string_to_array(current_stdout, E'
')) LOOP
                                  IF TRIM(line) = '' THEN
                                    CONTINUE;
                                  END IF;
                              
                                  solutions := solutions + 1;
                                  -- Append parsed values to arrays for the current batch
                                  certs := array_append(certs, SPLIT_PART(line, ' ', 1)::NUMERIC);
                                  graphs := array_append(graphs, SUBSTRING(line FROM POSITION(' ' IN line) + 1));
                                  batch_count := batch_count + 1;
                              
                                  -- If batch limit is reached, perform the batch insert and reset arrays
                                  IF batch_count >= BATCH_LIMIT THEN
                                    INSERT INTO conf_17_4.line_10_results (cert, graph)
                                    SELECT c, g
                                    FROM unnest(certs, graphs) AS t(c, g) -- Unnest both arrays side-by-side
                                    ON CONFLICT (cert) DO NOTHING;
                              
                                    -- Reset arrays and count for the next batch
                                    certs := '{}';
                                    graphs := '{}';
                                    batch_count := 0;
                                  END IF;
                              
                                END LOOP;
                              
                                -- After the loop, insert any remaining items in the last (possibly partial) batch
                                IF batch_count > 0 THEN
                                  INSERT INTO conf_17_4.line_10_results (cert, graph)
                                  SELECT c, g
                                  FROM unnest(certs, graphs) AS t(c, g)
                                  ON CONFLICT (cert) DO NOTHING;
                                END IF;
                                  
                                UPDATE conf_17_4.line_10 SET stdout = 'Done ' || solutions::text WHERE seq = seq_id;
                                DELETE FROM conf_17_4.line_10_pending_results WHERE seq = seq_id;
                              END;
                              $$;

alter function process_line_10_stdout(integer) owner to jcharlesan;

