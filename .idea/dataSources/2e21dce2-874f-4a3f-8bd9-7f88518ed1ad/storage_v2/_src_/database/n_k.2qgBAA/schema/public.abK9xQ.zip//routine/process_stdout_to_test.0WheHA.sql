create function process_stdout_to_test() returns trigger
    language plpgsql
as
$$
DECLARE
    line TEXT;
    extracted_key TEXT;
    extracted_value TEXT;
BEGIN
    -- Split the stdout string into individual lines
    FOR line IN SELECT * FROM unnest(string_to_array(NEW.stdout, E'\n')) LOOP
            -- Skip empty lines that might result from trailing newlines
            IF TRIM(line) = '' THEN
                CONTINUE;
            END IF;

            -- Split each line into key and value by the first space
            -- SPLIT_PART(string, delimiter, part_number)
            -- POSITION(substring IN string) returns the starting index of the first occurrence
            extracted_key := SPLIT_PART(line, ' ', 1);
            extracted_value := SUBSTRING(line FROM POSITION(' ' IN line) + 1);

            -- Insert into table_b, handling conflicts on the 'key'
            INSERT INTO conf_17_4.line_9_test (cert, graph)
            VALUES (extracted_key, extracted_value)
            ON CONFLICT (cert) DO NOTHING; -- Do nothing if the key already exists


        END LOOP;
    NEW.stdout := null;
    RETURN NEW; -- Important: Triggers must return NEW for AFTER triggers
END;
$$;

alter function process_stdout_to_test() owner to jcharlesan;

