create function process_line_3_stdout() returns trigger
    language plpgsql
as
$$
                              DECLARE
                                line TEXT;
                                current_cert TEXT;
                                current_graph TEXT;
                                solutions INTEGER;
                              BEGIN
                                IF PG_TRIGGER_DEPTH() = 1 THEN
                                  IF NEW.stdout NOT LIKE 'Reserved-%' THEN
                                    solutions:=0;
                                    FOR line IN SELECT * FROM unnest(string_to_array(NEW.stdout, E'
')) LOOP
                                      IF TRIM(line) = '' THEN
                                        CONTINUE;
                                      END IF;
                                      
                                      solutions:=solutions + 1;
                                      current_cert := SPLIT_PART(line, ' ', 1);
                                      current_graph := SUBSTRING(line FROM POSITION(' ' IN line) + 1);
      
                                      INSERT INTO conf_17_4.line_3_results (cert, graph)
                                      VALUES (current_cert, current_graph)
                                      ON CONFLICT (cert) DO NOTHING; 
                                    END LOOP;
                                    UPDATE conf_17_4.line_3 SET stdout = solutions::text WHERE seq = NEW.seq;
                                  END IF;
                                END IF;
                                RETURN NEW; 
                              END;
                              $$;

alter function process_line_3_stdout() owner to jcharlesan;

