create function notify_line_2_channel() returns trigger
    language plpgsql
as
$$
                              BEGIN
                                IF NEW.stdout NOT LIKE 'Reserved-%' AND NEW.stdout NOT LIKE 'Done %' THEN
                                  PERFORM pg_notify('line_2_channel', NEW.seq::text);
                                END IF;
                                RETURN NEW; 
                              END;
                              $$;

alter function notify_line_2_channel() owner to jcharlesan;

